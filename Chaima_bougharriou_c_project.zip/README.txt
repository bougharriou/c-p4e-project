Maze Game – P4E Project

Description:
This is a simple maze game.
The player controls the thief (T) and the computer controls the policeman (P).
The goal is to reach the exit (E) before the policeman catches the thief.

Rules:
- The maze size is 16x16.
- The thief and the policeman move up, down, left or right.
- Walls (W) cannot be crossed.
- If the thief reaches the exit, the player wins.
- If the policeman reaches the thief, the player loses.

Difficulty:
- Easy: the policeman moves randomly.
- Hard: the policeman moves closer to the thief.

How to run:
1. Open the project with Code::Blocks.
2. Build and Run the project.
3. Choose the difficulty level.
4. Use W, A, S, D to move the thief.

Author:
chaima bougharriou

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/* Maze size */
#define GRID_SIZE 16

/* Cells */
#define CELL_EMPTY  '.'
#define CELL_WALL   'W'
#define CELL_THIEF  'T'
#define CELL_COP    'P'
#define CELL_EXIT   'E'

/* Exit is at row 8, col 16 in the statement -> (7,15) in C indexing */
#define EXIT_ROW 7
#define EXIT_COL 15

/* prototypes*/
void setupMaze(char board[GRID_SIZE][GRID_SIZE]);
void putWalls(char board[GRID_SIZE][GRID_SIZE]);
void showMaze(const char board[GRID_SIZE][GRID_SIZE]);

int manhattan(int r1, int c1, int r2, int c2);
int isFreeCell(const char board[GRID_SIZE][GRID_SIZE], int r, int c);
void placeActors(char board[GRID_SIZE][GRID_SIZE], int *tr, int *tc, int *pr, int *pc);

void clearScreen(void);
int isWallOrOut(const char board[GRID_SIZE][GRID_SIZE], int r, int c);
int moveThief(char board[GRID_SIZE][GRID_SIZE], int *tr, int *tc);

int moveCop(char board[GRID_SIZE][GRID_SIZE],
            int *pr, int *pc,
            int tr, int tc,
            int level,
            int *prevPr, int *prevPc);

/* ---- maze setup ---- */
void setupMaze(char board[GRID_SIZE][GRID_SIZE]) {
    int r, c;

    /* start with empty cells */
    for (r = 0; r < GRID_SIZE; r++) {
        for (c = 0; c < GRID_SIZE; c++) {
            board[r][c] = CELL_EMPTY;
        }
    }

    /* put exit and walls */
    board[EXIT_ROW][EXIT_COL] = CELL_EXIT;
    putWalls(board);
}

void putWalls(char board[GRID_SIZE][GRID_SIZE]) {
    int i;

    /* a straightforward fixed layout */
    for (i = 2; i <= 13; i++) board[i][4] = CELL_WALL;
    for (i = 6; i <= 12; i++) board[10][i] = CELL_WALL;

    board[5][8] = CELL_WALL;
    board[6][8] = CELL_WALL;

    board[12][2] = CELL_WALL;
    board[12][3] = CELL_WALL;
    board[12][4] = CELL_WALL;
}

/* helper functions  */
int manhattan(int r1, int c1, int r2, int c2) {
    int dr = r2 - r1;
    int dc = c2 - c1;

    if (dr < 0) dr = -dr;
    if (dc < 0) dc = -dc;

    return dr + dc;
}

/* Free = inside + not a wall + not exit (for initial random placement) */
int isFreeCell(const char board[GRID_SIZE][GRID_SIZE], int r, int c) {
    if (r < 0 || r >= GRID_SIZE) return 0;
    if (c < 0 || c >= GRID_SIZE) return 0;
    if (board[r][c] == CELL_WALL) return 0;
    if (board[r][c] == CELL_EXIT) return 0;
    return 1;
}

/* Put thief and cop randomly with the distance rules */
void placeActors(char board[GRID_SIZE][GRID_SIZE], int *tr, int *tc, int *pr, int *pc) {
    int rT, cT, rP, cP;

    while (1) {
        rT = rand() % GRID_SIZE;
        cT = rand() % GRID_SIZE;
        if (!isFreeCell(board, rT, cT)) continue;
        if (manhattan(rT, cT, EXIT_ROW, EXIT_COL) < 16) continue;

        rP = rand() % GRID_SIZE;
        cP = rand() % GRID_SIZE;
        if (!isFreeCell(board, rP, cP)) continue;
        if (rP == rT && cP == cT) continue;
        if (manhattan(rT, cT, rP, cP) < 16) continue;

        break;
    }

    board[rT][cT] = CELL_THIEF;
    board[rP][cP] = CELL_COP;

    *tr = rT; *tc = cT;
    *pr = rP; *pc = cP;
}

void showMaze(const char board[GRID_SIZE][GRID_SIZE]) {
    int r, c;

    printf("    ");
    for (c = 0; c < GRID_SIZE; c++) printf("%2d", c + 1);
    printf("\n");

    for (r = 0; r < GRID_SIZE; r++) {
        printf("%2d |", r + 1);
        for (c = 0; c < GRID_SIZE; c++) {
            printf(" %c", board[r][c]);
        }
        printf("\n");
    }
}

/*game moves */
void clearScreen(void) {
    system("cls"); /* Windows */
}

int isWallOrOut(const char board[GRID_SIZE][GRID_SIZE], int r, int c) {
    if (r < 0 || r >= GRID_SIZE) return 1;
    if (c < 0 || c >= GRID_SIZE) return 1;
    if (board[r][c] == CELL_WALL) return 1;
    return 0;
}

/* Move thief with W/A/S/D. Return 1 if move ok, 0 if invalid */
int moveThief(char board[GRID_SIZE][GRID_SIZE], int *tr, int *tc) {
    char cmd;
    int newR = *tr;
    int newC = *tc;

    printf("\nMove (W/A/S/D): ");
    if (scanf(" %c", &cmd) != 1) return 0;

    if (cmd == 'w' || cmd == 'W') newR--;
    else if (cmd == 's' || cmd == 'S') newR++;
    else if (cmd == 'a' || cmd == 'A') newC--;
    else if (cmd == 'd' || cmd == 'D') newC++;
    else return 0;

    if (isWallOrOut(board, newR, newC)) return 0;

    /* clear old position (simple version) */
    board[*tr][*tc] = CELL_EMPTY;

    *tr = newR;
    *tc = newC;

    /* draw thief (note: if thief steps on exit, exit char is overwritten) */
    board[*tr][*tc] = CELL_THIEF;

    return 1;
}

/*
  Cop move:
  level 1 = random
  level 2 = pick move that gets closer (Manhattan)
  prevPr/prevPc helps avoid immediate backtracking when possible.
*/
int moveCop(char board[GRID_SIZE][GRID_SIZE],
            int *pr, int *pc,
            int tr, int tc,
            int level,
            int *prevPr, int *prevPc) {
    int dr[4] = {-1, 1, 0, 0};
    int dc[4] = {0, 0, -1, 1};

    int candR[4], candC[4];
    int count = 0;
    int i;

    /* collect possible moves */
    for (i = 0; i < 4; i++) {
        int nr = *pr + dr[i];
        int nc = *pc + dc[i];

        if (nr < 0 || nr >= GRID_SIZE) continue;
        if (nc < 0 || nc >= GRID_SIZE) continue;
        if (board[nr][nc] == CELL_WALL) continue;

        candR[count] = nr;
        candC[count] = nc;
        count++;
    }

    if (count == 0) return 1;

    /* avoid going back if we have other choices */
    if (count > 1) {
        for (i = 0; i < count; i++) {
            if (candR[i] == *prevPr && candC[i] == *prevPc) {
                int k;
                for (k = i; k < count - 1; k++) {
                    candR[k] = candR[k + 1];
                    candC[k] = candC[k + 1];
                }
                count--;
                break;
            }
        }
    }

    /* choose */
    int chosen = 0;

    if (level == 1) {
        chosen = rand() % count;
    } else {
        int bestDist = 99999;
        int bestIdx[4];
        int bestCount = 0;

        for (i = 0; i < count; i++) {
            int d = manhattan(candR[i], candC[i], tr, tc);
            if (d < bestDist) {
                bestDist = d;
                bestCount = 0;
                bestIdx[bestCount++] = i;
            } else if (d == bestDist) {
                bestIdx[bestCount++] = i;
            }
        }

        chosen = bestIdx[rand() % bestCount];
    }

    /* update previous position */
    *prevPr = *pr;
    *prevPc = *pc;

    /* clear old cop cell (restore exit if needed) */
    if (*pr == EXIT_ROW && *pc == EXIT_COL) board[*pr][*pc] = CELL_EXIT;
    else board[*pr][*pc] = CELL_EMPTY;

    *pr = candR[chosen];
    *pc = candC[chosen];

    board[*pr][*pc] = CELL_COP;

    return 1;
}

/*main */
int main(void) {
    char maze[GRID_SIZE][GRID_SIZE];

    int thiefRow, thiefCol;  /* names that are readable*/
    int copRow, copCol;

    int tr, tc, pr, pc;      /* short names used by functions */
    int prevPr, prevPc;
    int level;

    srand((unsigned)time(NULL));

    printf("Choose level: 1 = Easy, 2 = Hard : ");
    if (scanf("%d", &level) != 1) level = 1;
    if (level != 2) level = 1;

    setupMaze(maze);
    placeActors(maze, &tr, &tc, &pr, &pc);

    thiefRow = tr; thiefCol = tc;
    copRow   = pr; copCol   = pc;

    prevPr = pr;
    prevPc = pc;

    while (1) {
        clearScreen();
        showMaze(maze);

        while (!moveThief(maze, &tr, &tc)) {
            printf("Invalid move! Try again.\n");
        }

        thiefRow = tr; thiefCol = tc;

        /* win */
        if (thiefRow == EXIT_ROW && thiefCol == EXIT_COL) {
            clearScreen();
            showMaze(maze);
            printf("\nYou escaped!\n");
            break;
        }

        /* cop move */
        moveCop(maze, &pr, &pc, tr, tc, level, &prevPr, &prevPc);

        copRow = pr; copCol = pc;

        /* cop lose */
        if (copRow == thiefRow && copCol == thiefCol) {
            clearScreen();
            showMaze(maze);
            printf("\nCaught!\n");
            break;
        }
    }

    return 0;
}

/* End of file */


